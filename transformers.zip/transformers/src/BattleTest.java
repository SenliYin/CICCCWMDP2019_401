import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import rules.BasicRules;
import rules.SpecialRules;
import model.Team;
import model.Transformers;


public class BattleTest {
public static void main(String[] args) {
	
	Team a = new Team();
	Team b = new Team();
	BasicRules basic = new BasicRules();
	SpecialRules special = new SpecialRules();
	String teamAName;
	int battleNumber = 0;
	List<String> teamAList = new ArrayList<String>();
	List<String> teamBList = new ArrayList<String>();
	System.out.println("please enter transformers info:");
	Scanner str = new Scanner(System.in);
	String transformersString = str.next();
	String[] transformersList = transformersString.split(" ");
	teamAName = transformersList[0].split(",")[1];
	for(String transformerString : transformersList){
		String[] tmp = transformerString.split(",");
		String teamName = tmp[1];
		if(teamName.equals(teamAName)){
			teamAList.add(transformerString);
		}else{
			teamBList.add(transformerString);
		}
	}
	
	Team teamA = sort(teamAList);
	Team teamB = sort(teamBList);
	Transformers survivors = new Transformers(); 
	int aWinAmt = 0;
	int bWinAmt = 0;
	List<Transformers> teamATrans = new ArrayList<Transformers>();
	teamATrans = teamA.getTransformerList();
	List<Transformers> teamBTrans = new ArrayList<Transformers>();
	teamBTrans = teamB.getTransformerList();
	if(teamA.getAmount() > teamB.getAmount()){
		battleNumber = teamB.getAmount();
	}else if (teamA.getAmount() == teamB.getAmount()){
		battleNumber = teamA.getAmount();
	}else{
		battleNumber = teamA.getAmount();
	}
	System.out.println("battle begine----------");
	for(int i = 0 ;i < battleNumber-1; i++){
		System.out.println("battle"+i+"-----");
		Transformers win = new Transformers();
		win = special.battle(teamATrans.get(i), teamBTrans.get(i));
		if(win != null){
			System.out.println(win.getTeamName()+"is win");
			if(win.getTeamName().equals(teamA.getTeamName())){
				aWinAmt = aWinAmt + 1;
			}else{
				bWinAmt = bWinAmt + 1;
			}
		}else{
			win = basic.battle(teamATrans.get(i), teamBTrans.get(i));
			if(win != null){
				System.out.println(win.getTeamName()+"is win");
				if(win.getTeamName().equals(teamA.getTeamName())){
					aWinAmt = aWinAmt + 1;
				}else{
					bWinAmt = bWinAmt + 1;
				}
			}else{
				System.out.println("battle"+i+" is tie");
			}
		}
	}
	if(aWinAmt > bWinAmt){
		System.out.println(teamA.getTeamName() + " is winner !");
		if(teamB.getAmount() > battleNumber){
			survivors = teamBTrans.get(battleNumber+1);
		}
	}else if (aWinAmt < bWinAmt){
		System.out.println(teamB.getTeamName() + " is winner !");
		if(teamA.getAmount() > battleNumber){
			survivors = teamATrans.get(battleNumber+1);
		}
	}else {
		System.out.println("The battle is tie !");
	}
	
}
public static Team sort(List<String> teamAList){
	Team sortedTeam = new Team();
	List<Transformers> transforList = new ArrayList<Transformers>();
	Map<String, Object> transformersMap = new HashMap<String, Object>();
	int[] rankList = new int[teamAList.size()];
	int count = 0;
	sortedTeam.setAmount(rankList.length);
	for(String transformerString : teamAList){
		String[] tmp = transformerString.split(",");
		Transformers transformer = new Transformers();
		transformer.setTransformerName(tmp[0]);
		transformer.setTeamName(tmp[1]);
		sortedTeam.setTeamName(tmp[1]);
		transformer.setStrength(Integer.parseInt(tmp[2]));
		transformer.setIntelligence(Integer.parseInt(tmp[3]));
		transformer.setSpeed(Integer.parseInt(tmp[4]));
		transformer.setEndurance(Integer.parseInt(tmp[5]));
		transformer.setRank(Integer.parseInt(tmp[6]));
		transformer.setCourage(Integer.parseInt(tmp[7]));
		transformer.setFirepower(Integer.parseInt(tmp[8]));
		transformer.setSkill(Integer.parseInt(tmp[9]));
		rankList[count] = Integer.parseInt(tmp[6]);
		count = count + 1;
		transformersMap.put(tmp[6], transformer);
	}
	for (int i = 0; i < rankList.length - 1; i++){    
		for(int j = 0 ;j < rankList.length - i - 1; j++){   
	        if(rankList[j] < rankList[j + 1]){
	            int temp = rankList[j];
	            rankList[j] = rankList[j + 1];
	            rankList[j + 1] = temp;
	        }
		}            
	}
	for(int rank : rankList){
		String rankS = rank + "";
		transforList.add((Transformers) transformersMap.get(rankS));
	}
	sortedTeam.setTransformerList(transforList);
	return sortedTeam;
}
}
