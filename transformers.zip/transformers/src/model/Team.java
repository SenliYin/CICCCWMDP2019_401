package model;

import java.util.List;

public class Team {
	String teamName;
	List<Transformers> transformerList;
	int amount;
	public String getTeamName() {
		return teamName;
	}
	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}
	
	public void setTransformers(List<Transformers> TransformerList) {
		TransformerList = this.transformerList;
	}
	public List<Transformers> getTransformerList() {
		return transformerList;
	}
	public void setTransformerList(List<Transformers> transformerList) {
		this.transformerList = transformerList;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	
}
