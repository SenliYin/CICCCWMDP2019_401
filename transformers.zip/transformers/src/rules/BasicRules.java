package rules;

import model.Transformers;

public class BasicRules{

	public Transformers battle(Transformers a, Transformers b){
		if(a.getSkill()>b.getSkill()&&(a.getSkill()-b.getSkill())>=3){
			return a;
		}else if(b.getSkill()>a.getSkill() && (b.getSkill() - a.getSkill())>= 3){
			return b;
		}else{
		}
		if(a.getCourage()>b.getCourage() && (a.getCourage() - b.getCourage()) >= 4
				&& a.getStrength() > b.getStrength() && (a.getStrength() - b.getStrength()) >= 3){
			return a;
		}else if (b.getCourage()>a.getCourage() && (b.getCourage() - a.getCourage()) >= 4
				&& b.getStrength() > a.getStrength() && (b.getStrength() - a.getStrength()) >= 3){
			return b;
		}else{
			
		}
		if(a.rating() > b.rating()){
			return a;		
		}else if(a.rating() < b.rating()){
			return b; 
		}else{
			return null;
		}
	}
}
