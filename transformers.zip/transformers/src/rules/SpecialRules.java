package rules;

import model.Transformers;

public class SpecialRules {

	public Transformers battle(Transformers a, Transformers b){
		if(a.getTransformerName().equals("Optimus Prime") || a.getTransformerName().equals("Predaking")){
			return a;
		}else if (b.getTransformerName().equals("Optimus Prime") || b.getTransformerName().equals("Predaking")){
			return b;
		}else
			return null;
	}
}
