package rules;

import model.Transformers;

public class Rules {

	public Transformers battle(){
		return new Transformers();
	}
}
